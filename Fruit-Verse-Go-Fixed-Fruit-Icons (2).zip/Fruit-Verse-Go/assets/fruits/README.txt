Fruit Verse Go fruit icon assets

These 36 icons are cropped from the user's supplied reference screenshot. The colored rarity tiles/backgrounds have been removed to make the fruit artwork transparent while preserving source artwork colors and details. Because the source was a phone screenshot, these are not original full-resolution game assets.
