# Fruit Verse Go 🍈🎮

A new Flutter Android starter for an AR-style fruit hunt. The Fruit Book contains **36 distinct icon crops** taken directly from the fruit-chart screenshot supplied by the project owner. The images have not been AI-redrawn, recolored, or replaced with emoji.

## Fruit catalogue
- 36 image assets: `assets/fruits/fruit_01.png` through `fruit_36.png`.
- Categories: Mythical, Legendary, Rare, Uncommon, and Common.
- The same exact image asset is used in the fruit book, discovery dialog, and inventory.
- Names are temporary identifiers (`Fruit 01`, etc.) because the reference screenshot doesn't provide all readable names.

## Build an APK using only an Android phone
1. Download and extract this ZIP on your phone.
2. Open your GitHub repository `Fruit-Verse-Go-`.
3. Choose **Add file → Upload files**.
4. Upload the contents of the `Fruit-Verse-Go` folder to the **root** of the repository. The root should contain `pubspec.yaml`, `lib/`, `assets/`, `android/`, and `.github/`.
5. Tap **Commit changes** on the `main` branch.
6. Open **Actions** and select **Build Fruit Verse Go APK**.
7. Tap **Run workflow** if it did not start automatically, then wait for a green check mark.
8. Open the successful run, scroll to **Artifacts**, download `fruit-verse-go-apk`, extract that downloaded ZIP, and install `app-release.apk`.

## Honest prototype notes
- The AR page attempts to open the phone's AR camera if the Android device/plugin supports it. The collect button currently simulates discovery while retaining the original fruit icon.
- GPS-based fruit spawning, persistent player accounts, actual 3D objects anchored in the camera view, online trading, multiplayer, and secure admin moderation are not implemented in this starter.
- AR support depends on the Android device and Google Play Services for AR. GitHub Actions must finish successfully before an APK exists.
- The supplied screenshot contains third-party game-style artwork. This ZIP preserves the icons as requested; make sure you have permission for any public or commercial release.
