import 'dart:math';

import 'package:ar_flutter_plugin/ar_flutter_plugin.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const FruitVerseGo());

class FruitVerseGo extends StatelessWidget {
  const FruitVerseGo({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Fruit Verse Go',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF8B35D1),
            brightness: Brightness.dark,
          ),
          scaffoldBackgroundColor: const Color(0xFF14121A),
          useMaterial3: true,
        ),
        home: const WelcomeGate(),
      );
}


class WelcomeGate extends StatefulWidget {
  const WelcomeGate({super.key});
  @override
  State<WelcomeGate> createState() => _WelcomeGateState();
}

class _WelcomeGateState extends State<WelcomeGate> {
  bool _showLogin = false;
  bool _obscurePassword = true;
  final _username = TextEditingController();
  final _password = TextEditingController();

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _showLogin = true);
    });
  }

  @override
  void dispose() {
    _username.dispose();
    _password.dispose();
    super.dispose();
  }

  void _enterGame() {
    if (_username.text.trim().isEmpty || _password.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter a username and password, or choose Play as Guest.')),
      );
      return;
    }
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const GameHomePage()));
  }

  void _guestPlay() {
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const GameHomePage()));
  }

  @override
  Widget build(BuildContext context) {
    const purple = Color(0xFF9B4DFF);
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [Color(0xFF21143A), Color(0xFF111018), Color(0xFF25102D)]),
        ),
        child: SafeArea(
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 450),
            child: !_showLogin
              ? Column(key: const ValueKey('loading'), mainAxisAlignment: MainAxisAlignment.center, children: [
                  Container(width: 116, height: 116, decoration: BoxDecoration(color: purple.withOpacity(.18),
                    borderRadius: BorderRadius.circular(30), border: Border.all(color: purple, width: 2)),
                    child: const Icon(Icons.auto_awesome, size: 70, color: Color(0xFFFFD54F))),
                  const SizedBox(height: 24),
                  const Text('FRUIT VERSE GO', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900, letterSpacing: 2)),
                  const SizedBox(height: 10),
                  const Text('Your next rare fruit is out there…', style: TextStyle(color: Colors.white70)),
                  const SizedBox(height: 34),
                  const SizedBox(width: 170, child: LinearProgressIndicator(minHeight: 5, color: Color(0xFFFFD54F), backgroundColor: Colors.white12)),
                  const SizedBox(height: 12),
                  const Text('LOADING ADVENTURE', style: TextStyle(color: Colors.white54, letterSpacing: 2, fontSize: 11)),
                ])
              : Center(key: const ValueKey('login'), child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 420), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  const Icon(Icons.travel_explore, size: 68, color: Color(0xFFFFD54F)),
                  const SizedBox(height: 12),
                  const Text('WELCOME, HUNTER!', textAlign: TextAlign.center, style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 8),
                  const Text('Sign in to start your fruit adventure', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70)),
                  const SizedBox(height: 30),
                  TextField(controller: _username, textInputAction: TextInputAction.next, autofillHints: const [AutofillHints.username],
                    decoration: InputDecoration(labelText: 'Username', prefixIcon: const Icon(Icons.person_outline), filled: true,
                      fillColor: Colors.white.withOpacity(.06), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)))),
                  const SizedBox(height: 14),
                  TextField(controller: _password, obscureText: _obscurePassword, autofillHints: const [AutofillHints.password],
                    decoration: InputDecoration(labelText: 'Password', prefixIcon: const Icon(Icons.lock_outline), filled: true,
                      fillColor: Colors.white.withOpacity(.06), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                      suffixIcon: IconButton(icon: Icon(_obscurePassword ? Icons.visibility : Icons.visibility_off),
                        onPressed: () => setState(() => _obscurePassword = !_obscurePassword)))),
                  const SizedBox(height: 22),
                  FilledButton(onPressed: _enterGame, style: FilledButton.styleFrom(backgroundColor: purple, padding: const EdgeInsets.symmetric(vertical: 16)),
                    child: const Text('LOG IN', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1))),
                  const SizedBox(height: 12),
                  OutlinedButton(onPressed: _guestPlay, style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 15), side: const BorderSide(color: Colors.white30)),
                    child: const Text('PLAY AS GUEST')),
                  const SizedBox(height: 18),
                  const Text('Demo sign-in screen: accounts are not yet connected to an online authentication service.',
                    textAlign: TextAlign.center, style: TextStyle(color: Colors.white54, fontSize: 12)),
                ]),
              )),
          ),
        ),
      ),
    );
  }
}

class FruitEntry {
  const FruitEntry({required this.id, required this.name, required this.rarity, required this.image});
  final int id;
  final String name;
  final String rarity;
  final String image;
}

// These 36 images are direct crops of the user's supplied fruit-chart screenshot.
// They are not AI-redrawn, recolored, or replaced with emoji.
const List<FruitEntry> fruitCatalog = [
  FruitEntry(id: 1, name: 'Fruit 01', rarity: 'Mythical', image: 'assets/fruits/fruit_01.png'),
  FruitEntry(id: 2, name: 'Fruit 02', rarity: 'Mythical', image: 'assets/fruits/fruit_02.png'),
  FruitEntry(id: 3, name: 'Fruit 03', rarity: 'Mythical', image: 'assets/fruits/fruit_03.png'),
  FruitEntry(id: 4, name: 'Fruit 04', rarity: 'Mythical', image: 'assets/fruits/fruit_04.png'),
  FruitEntry(id: 5, name: 'Fruit 05', rarity: 'Mythical', image: 'assets/fruits/fruit_05.png'),
  FruitEntry(id: 6, name: 'Fruit 06', rarity: 'Mythical', image: 'assets/fruits/fruit_06.png'),
  FruitEntry(id: 7, name: 'Fruit 07', rarity: 'Mythical', image: 'assets/fruits/fruit_07.png'),
  FruitEntry(id: 8, name: 'Fruit 08', rarity: 'Mythical', image: 'assets/fruits/fruit_08.png'),
  FruitEntry(id: 9, name: 'Fruit 09', rarity: 'Legendary', image: 'assets/fruits/fruit_09.png'),
  FruitEntry(id: 10, name: 'Fruit 10', rarity: 'Legendary', image: 'assets/fruits/fruit_10.png'),
  FruitEntry(id: 11, name: 'Fruit 11', rarity: 'Legendary', image: 'assets/fruits/fruit_11.png'),
  FruitEntry(id: 12, name: 'Fruit 12', rarity: 'Legendary', image: 'assets/fruits/fruit_12.png'),
  FruitEntry(id: 13, name: 'Fruit 13', rarity: 'Legendary', image: 'assets/fruits/fruit_13.png'),
  FruitEntry(id: 14, name: 'Fruit 14', rarity: 'Legendary', image: 'assets/fruits/fruit_14.png'),
  FruitEntry(id: 15, name: 'Fruit 15', rarity: 'Legendary', image: 'assets/fruits/fruit_15.png'),
  FruitEntry(id: 16, name: 'Fruit 16', rarity: 'Legendary', image: 'assets/fruits/fruit_16.png'),
  FruitEntry(id: 17, name: 'Fruit 17', rarity: 'Legendary', image: 'assets/fruits/fruit_17.png'),
  FruitEntry(id: 18, name: 'Fruit 18', rarity: 'Legendary', image: 'assets/fruits/fruit_18.png'),
  FruitEntry(id: 19, name: 'Fruit 19', rarity: 'Legendary', image: 'assets/fruits/fruit_19.png'),
  FruitEntry(id: 20, name: 'Fruit 20', rarity: 'Rare', image: 'assets/fruits/fruit_20.png'),
  FruitEntry(id: 21, name: 'Fruit 21', rarity: 'Rare', image: 'assets/fruits/fruit_21.png'),
  FruitEntry(id: 22, name: 'Fruit 22', rarity: 'Rare', image: 'assets/fruits/fruit_22.png'),
  FruitEntry(id: 23, name: 'Fruit 23', rarity: 'Rare', image: 'assets/fruits/fruit_23.png'),
  FruitEntry(id: 24, name: 'Fruit 24', rarity: 'Uncommon', image: 'assets/fruits/fruit_24.png'),
  FruitEntry(id: 25, name: 'Fruit 25', rarity: 'Uncommon', image: 'assets/fruits/fruit_25.png'),
  FruitEntry(id: 26, name: 'Fruit 26', rarity: 'Uncommon', image: 'assets/fruits/fruit_26.png'),
  FruitEntry(id: 27, name: 'Fruit 27', rarity: 'Uncommon', image: 'assets/fruits/fruit_27.png'),
  FruitEntry(id: 28, name: 'Fruit 28', rarity: 'Uncommon', image: 'assets/fruits/fruit_28.png'),
  FruitEntry(id: 29, name: 'Fruit 29', rarity: 'Uncommon', image: 'assets/fruits/fruit_29.png'),
  FruitEntry(id: 30, name: 'Fruit 30', rarity: 'Common', image: 'assets/fruits/fruit_30.png'),
  FruitEntry(id: 31, name: 'Fruit 31', rarity: 'Common', image: 'assets/fruits/fruit_31.png'),
  FruitEntry(id: 32, name: 'Fruit 32', rarity: 'Common', image: 'assets/fruits/fruit_32.png'),
  FruitEntry(id: 33, name: 'Fruit 33', rarity: 'Common', image: 'assets/fruits/fruit_33.png'),
  FruitEntry(id: 34, name: 'Fruit 34', rarity: 'Common', image: 'assets/fruits/fruit_34.png'),
  FruitEntry(id: 35, name: 'Fruit 35', rarity: 'Common', image: 'assets/fruits/fruit_35.png'),
  FruitEntry(id: 36, name: 'Fruit 36', rarity: 'Common', image: 'assets/fruits/fruit_36.png'),
];

Color rarityColor(String rarity) {
  switch (rarity) {
    case 'Mythical': return const Color(0xFFFF6262);
    case 'Legendary': return const Color(0xFFD64BF2);
    case 'Rare': return const Color(0xFF9E82FF);
    case 'Uncommon': return const Color(0xFF63CFFF);
    default: return const Color(0xFFE0E0E0);
  }
}

class GameHomePage extends StatefulWidget {
  const GameHomePage({super.key});
  @override
  State<GameHomePage> createState() => _GameHomePageState();
}

class _GameHomePageState extends State<GameHomePage> {
  int _tab = 0;
  int coins = 0;
  int totalFound = 0;
  final List<int> inventory = [];
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      coins = prefs.getInt('coins') ?? 0;
      totalFound = prefs.getInt('found') ?? 0;
      inventory
        ..clear()
        ..addAll((prefs.getStringList('inventory_ids') ?? []).map((s) => int.tryParse(s)).whereType<int>());
      _loaded = true;
    });
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('coins', coins);
    await prefs.setInt('found', totalFound);
    await prefs.setStringList('inventory_ids', inventory.map((id) => id.toString()).toList());
  }

  Future<void> _collectFruit() async {
    final fruit = fruitCatalog[Random().nextInt(fruitCatalog.length)];
    setState(() {
      inventory.add(fruit.id);
      coins += 10;
      totalFound += 1;
    });
    await _save();
    if (!mounted) return;
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Fruit discovered!'),
        content: Row(children: [
          SizedBox(width: 94, height: 94, child: Image.asset(fruit.image, fit: BoxFit.contain)),
          const SizedBox(width: 12),
          Expanded(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(fruit.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            Text(fruit.rarity, style: TextStyle(color: rarityColor(fruit.rarity))),
            const SizedBox(height: 4), const Text('+10 coins'),
          ])),
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('AWESOME'))],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _homeContent(),
      _fruitGrid(fruitCatalog, title: 'Fruit Collection', subtitle: '36 original icons from your reference image'),
      _fruitGrid(inventory.map((id) => fruitCatalog[id - 1]).toList().reversed.toList(), title: 'My Inventory', subtitle: '${inventory.length} fruits collected'),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('🍈 Fruit Verse Go'), centerTitle: true),
      body: !_loaded ? const Center(child: CircularProgressIndicator()) : pages[_tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (value) => setState(() => _tab = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.explore_outlined), selectedIcon: Icon(Icons.explore), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.grid_view), label: 'Fruit Book'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), label: 'Inventory'),
        ],
      ),
    );
  }

  Widget _homeContent() => ListView(padding: const EdgeInsets.all(16), children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF55208A), Color(0xFF123E49)]),
            borderRadius: BorderRadius.circular(22),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('YOUR FRUIT ADVENTURE', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.2)),
            const SizedBox(height: 8),
            const Text('Explore. Discover. Collect.', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
            const SizedBox(height: 18),
            Row(children: [
              Expanded(child: _stat('TOTAL FOUND', '$totalFound')),
              const SizedBox(width: 12),
              Expanded(child: _stat('COINS', '$coins')),
              const SizedBox(width: 12),
              Expanded(child: _stat('FRUIT TYPES', '${fruitCatalog.length}')),
            ]),
          ]),
        ),
        const SizedBox(height: 14),
        SizedBox(height: 52, child: FilledButton.icon(
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ARHuntPage(onCollect: _collectFruit))),
          icon: const Icon(Icons.camera_alt), label: const Text('START AR HUNT'),
        )),
        const SizedBox(height: 8),
        SizedBox(height: 50, child: OutlinedButton.icon(
          onPressed: _collectFruit, icon: const Icon(Icons.auto_awesome), label: const Text('QUICK TEST: DISCOVER A FRUIT'),
        )),
        const SizedBox(height: 22),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('FRUIT PREVIEW', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          TextButton(onPressed: () => setState(() => _tab = 1), child: const Text('VIEW ALL 36')),
        ]),
        SizedBox(height: 116, child: ListView.separated(
          scrollDirection: Axis.horizontal,
          itemCount: fruitCatalog.length,
          separatorBuilder: (_, __) => const SizedBox(width: 10),
          itemBuilder: (context, index) => SizedBox(width: 96, child: Column(children: [
            Expanded(child: Image.asset(fruitCatalog[index].image, fit: BoxFit.contain)),
            Text(fruitCatalog[index].name, style: const TextStyle(fontSize: 11), overflow: TextOverflow.ellipsis),
          ])),
        )),
        const SizedBox(height: 18),
        const Text('Prototype: the AR screen opens your camera on compatible phones. This version does not yet place 3D fruit objects in the real world or include online trading/multiplayer.', style: TextStyle(color: Colors.white70)),
      ]);

  Widget _stat(String title, String value) => Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(12)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w700)),
          const SizedBox(height: 4), Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        ]),
      );

  Widget _fruitGrid(List<FruitEntry> fruits, {required String title, required String subtitle}) {
    final width = MediaQuery.of(context).size.width;
    final count = width > 600 ? 4 : 2;
    return CustomScrollView(slivers: [
      SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(16, 16, 16, 8), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
        const SizedBox(height: 4), Text(subtitle, style: const TextStyle(color: Colors.white70)),
      ]))),
      if (fruits.isEmpty)
        const SliverFillRemaining(hasScrollBody: false, child: Center(child: Text('No fruits collected yet. Start a hunt!')))
      else
        SliverPadding(padding: const EdgeInsets.all(12), sliver: SliverGrid.builder(
          itemCount: fruits.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: count, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 0.78),
          itemBuilder: (context, index) {
            final fruit = fruits[index];
            return Card(clipBehavior: Clip.antiAlias, child: Padding(padding: const EdgeInsets.all(9), child: Column(children: [
              Expanded(child: Center(child: Image.asset(fruit.image, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image)))),
              const SizedBox(height: 6),
              Text(fruit.name, style: const TextStyle(fontWeight: FontWeight.bold), textAlign: TextAlign.center),
              const SizedBox(height: 2),
              Text(fruit.rarity, style: TextStyle(color: rarityColor(fruit.rarity), fontSize: 12)),
            ])));
          },
        )),
    ]);
  }
}

class ARHuntPage extends StatefulWidget {
  const ARHuntPage({super.key, required this.onCollect});
  final Future<void> Function() onCollect;
  @override
  State<ARHuntPage> createState() => _ARHuntPageState();
}

class _ARHuntPageState extends State<ARHuntPage> {
  bool failed = false;
  bool collecting = false;

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('AR Fruit Hunt')),
        body: Stack(children: [
          Positioned.fill(
            child: failed
                ? const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('AR could not start. Check camera permission and Google Play Services for AR support on your phone.', textAlign: TextAlign.center)))
                : ARView(onARViewCreated: (controller) {}, onError: (error) { if (mounted) setState(() => failed = true); }),
          ),
          Positioned(left: 18, right: 18, bottom: 22, child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Card(child: Padding(padding: EdgeInsets.all(14), child: Text('Look around, then tap to simulate finding one of the 36 reference fruits. True GPS spawning and 3D placement are future features.', textAlign: TextAlign.center))),
            const SizedBox(height: 8),
            SizedBox(width: double.infinity, height: 54, child: FilledButton.icon(
              onPressed: collecting ? null : () async { setState(() => collecting = true); await widget.onCollect(); if (mounted) setState(() => collecting = false); },
              icon: const Icon(Icons.add_circle_outline), label: Text(collecting ? 'COLLECTING…' : 'COLLECT DISCOVERED FRUIT'),
            )),
          ])),
        ]),
      );
}
